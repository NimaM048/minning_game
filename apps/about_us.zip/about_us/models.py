# apps/core/models.py

from django.db import models

class ContactInfo(models.Model):
    support_phone = models.CharField(max_length=30)
    email = models.EmailField()
    address = models.TextField()
    about_us_text = models.TextField()
    telegram = models.URLField(blank=True, null=True)
    instagram = models.URLField(blank=True, null=True)
    twitter = models.URLField(blank=True, null=True)
    linkedin = models.URLField(blank=True, null=True)

    class Meta:
        verbose_name = "Contact Info"
        verbose_name_plural = "Contact Info"

    def __str__(self):
        return "Contact Information"
