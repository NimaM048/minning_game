from rest_framework.views import APIView
from rest_framework.response import Response
from .models import ContactInfo
from .serializers import ContactInfoSerializer
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi

class ContactInfoView(APIView):
    @swagger_auto_schema(
        operation_description="دریافت اطلاعات تماس سایت (ایمیل، تلفن، آدرس)",
        responses={200: ContactInfoSerializer()}
    )
    def get(self, request):
        contact = ContactInfo.objects.first()
        if not contact:
            return Response({"detail": "اطلاعات تماس ثبت نشده است"}, status=404)
        return Response(ContactInfoSerializer(contact).data)
